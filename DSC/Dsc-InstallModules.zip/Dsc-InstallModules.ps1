Configuration InstallModules
{
  param ($NodeName)

  Import-DscResource -ModuleName PSDesiredStateConfiguration

  Node $NodeName
  {
        Script InstallModules
        {
            SetScript = 
            {
                New-Item C:\temp -ItemType Directory -Force
                "dsc works" | Out-File "C:\temp\dsc.txt" -Force
                Install-Module xSmbShare -Force
                Install-Module cNtfsAccessControl -Force
            }
            TestScript = 
            {
                Test-Path "C:\temp\dsc.txt"
            }
            GetScript = 
            {
                @{Result = "InstallModules"}
            }
        }

        Script ImportlModules
        {
            SetScript = 
            {
                Import-Module xSmbShare -Force
                Import-Module cNtfsAccessControl -Force
            }
            TestScript = 
            {
                Test-Path "C:\temp\dsc.txt"
            }
            GetScript = 
            {
                @{Result = "ImportModules"}
            }
        }
  }
} 

#InstallModules -OutputPath C:\ -NodeName "localhost"
#Start-DscConfiguration -Wait -Force -Path C:\ -ComputerName localhost -Verbose
#Set-DscLocalConfigurationManager -Path "C:\" -Force -Verbose -ComputerName


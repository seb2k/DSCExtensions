Configuration Webserver
{
  param ($NodeName)

  Node $NodeName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }

    Script HelloWorld
    {
        TestScript = {
            Test-Path "C:\inetpub\wwwroot\iisstart.html"
        }
        SetScript ={
            
            New-Item     C:\inetpub\wwwroot -ItemType Directory -Force

            "<html>
            <head>
            <title>Hello World!</title>
            </head>
            <body>
            Hello World!<br><br>
            <b>Hostname</b> $NodeName
            </body>
            </html>" | Out-File "C:\inetpub\wwwroot\iisstart.html" -Force
             
        }
        GetScript = {@{Result = "HelloWorld"}}
        DependsOn = "[WindowsFeature]IIS"
    }
  }
} 